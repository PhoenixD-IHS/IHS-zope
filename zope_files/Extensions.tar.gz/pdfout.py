import re, io
from reportlab.platypus.paragraph import Paragraph
from reportlab.platypus.tables import Table
from reportlab.platypus.tables import TableStyle
from reportlab.platypus.doctemplate import *
from reportlab.platypus import Frame, Spacer
from reportlab.lib.units import mm
from reportlab.lib import styles
from reportlab.lib import colors

LEFT = 20*mm
RIGHT = 10*mm
TOP = 15*mm
BOTTOM = 25*mm
FOOT = BOTTOM-5*mm
HEAD = TOP-5*mm

PADLEFT = 6
PADRIGHT = 6
PADBOTTOM = 6
PADTOP = 6

FONT = "Helvetica"
BOLD = "Helvetica-Bold"
FONTSIZE = 6

LINE = 0.2

######################################################################
def specialChars(s):
    if type(s) == type(""):
        s = s.replace("&nbsp;", " ")
        s = s.replace("&euro;", "\200")
        s = re.sub("<br>", " ", s)
        s = re.sub("</?[a-z][^>]*>", "", s)
    return s


######################################################################
def specialTab(data):
    for i in range(len(data)):
        for j in range(len(data[i])):
            data[i][j] = specialChars(data[i][j])
    return data


######################################################################
class FullTable(Table):
    def setTabWidth(self, width):
        self.tabwidth = width
        
    def _calc_width(self, availwidth, W=None):
        Table._calc_width(self, availwidth, W)
        if "tabwidth" in self.__dict__.keys():
            if self._width:
                f = self.tabwidth / self._width
                W = self._colWidths
                W = W[:]
                self._colWidths = W
                width = 0
                self._colpositions = [0]
                for i in range(len(W)):
                    print( W[i], width)
                    W[i] = f * W[i]
                    width = width + W[i]
                    self._colpositions.append(width)
                self._width = width

    
######################################################################
class IHSPageTemplate(PageTemplate):
    def __init__(self, pname, parent, version, name, date, time, user):
        self.parent = parent
        self.version = version
        self.name = name
        self.date = date
        self.time = time
        self.user = user
        content = Frame(LEFT,
                        BOTTOM,
                        parent.document.pagesize[0]-LEFT-RIGHT,
                        parent.document.pagesize[1]-BOTTOM-TOP,
                        PADLEFT, PADRIGHT, PADBOTTOM, PADTOP)
        PageTemplate.__init__(self, pname, [content])
        
    def beforeDrawPage(self, canvas, doc):
        canvas.saveState()
        canvas.setFont(FONT, FONTSIZE)
        
        # Header
        p = canvas.beginPath()
        p.moveTo(LEFT, doc.pagesize[1]-HEAD)
        p.lineTo(doc.pagesize[0]-RIGHT, doc.pagesize[1]-HEAD)
        canvas.drawPath(p)
        canvas.drawString(LEFT,
                          doc.pagesize[1]-HEAD+0.3*FONTSIZE,
                          "Institutshaushaltssystem %s" % self.version)
        canvas.drawCentredString(LEFT+(doc.pagesize[0]-LEFT-RIGHT)/2,
                                 doc.pagesize[1]-HEAD+0.3*FONTSIZE,
                                 self.name)
        canvas.drawRightString(doc.pagesize[0]-RIGHT,
                               doc.pagesize[1]-HEAD+0.3*FONTSIZE,
                               "Seite: %s" % doc.page)

        # Footer
        p = canvas.beginPath()
        p.moveTo(LEFT, FOOT)
        p.lineTo(doc.pagesize[0]-RIGHT, FOOT)
        canvas.drawPath(p)
        canvas.drawString(LEFT,
                          FOOT-FONTSIZE,
                          "Zeit: %s" % self.time)
        canvas.drawCentredString(LEFT+(doc.pagesize[0]-LEFT-RIGHT)/2,
                                 FOOT-FONTSIZE,
                                 "Benutzer: %s" % self.user)
        canvas.drawRightString(doc.pagesize[0]-RIGHT,
                               FOOT-FONTSIZE,
                               "Datum: %s" % self.date)
        canvas.restoreState()


######################################################################
class IHSDocument:
    def __init__(self, version, name, date, time, user):
        self.built = 0
        self.objects = []

        # we will build an in-memory document
        # instead of creating an on-disk file.
        self.report = io.BytesIO()

        # initialise a PDF document using ReportLab's platypus
        self.document = BaseDocTemplate(self.report)

        # add our page template
        # (we could add more than one, but I prefer to keep it simple)
        self.document.addPageTemplates(
            IHSPageTemplate("Text", self, version, name, date, time, user))
        
        self.tabwidth = self.document.pagesize[0] - \
                        (LEFT + PADLEFT + PADRIGHT + RIGHT)
        
        # get the default style sheets
        #self.StyleSheet = styles.getSampleStyleSheet()

    def __str__(self):
        if not self.built:
            self.build()
        return self.report.getvalue().decode("latin1")

    def append(self, object):
        self.objects.append(object)

    def build(self):
        self.document.build(self.objects)
        self.built = 1

    def pageBreak(self):
        self.append(PageBreak())

    def appendSpacer(self, y):
        self.append(Spacer(0, y))
        
    def appendHeadline(self, s):
        # prepare data
        data = [[s]]

        # row heights
        rh = [1.2*FONTSIZE]
        
        # prepare table
        data = specialTab(data)
        t = Table(data, None, rh)
        t.hAlign = "CENTER"
        style = []

        # fonts
        style.append(("FONT", (0,0), (-1,-1), BOLD))
        style.append(("FONTSIZE", (0,0), (-1,-1), FONTSIZE))

        # cell padding
        style.append(("LEFTPADDING", (0,0), (-1,-1), 6))
        style.append(("RIGHTPADDING", (0,0), (-1,-1), 6))
        style.append(("BOTTOMPADDING", (0,0), (-1,-1), 0))
        style.append(("TOPPADDING", (0,0), (-1,-1), 0.6*FONTSIZE))

        # alignment
        style.append(("VALIGN", (0,0), (-1,-1), "MIDDLE"))
        style.append(("ALIGN", (0,0), (-1,-1), "CENTER"))

        # apply style
        t.setStyle(TableStyle(style))
        self.append(t)
        
    def appendHeadtable(self, list, align):
        # prepare data
        data = []
        for l,c,r in list[0]:
            if c == "select":
                list = r["list"]
                sel = r["selected"]
                for key, value in list:
                    if key == sel:
                        r = value
                        break
            data.append([l, r])
        rows = len(data)

        # row heights
        rh = rows*[1.2*FONTSIZE]
        
        # prepare table
        data = specialTab(data)
        t = Table(data, None, rh)
        t.hAlign = align
        style = []

        # fonts
        style.append(("FONT", (0,0), (-1,-1), FONT))
        style.append(("FONT", (0,0), (0,-1), BOLD))
        style.append(("FONTSIZE", (0,0), (-1,-1), FONTSIZE))

        # cell padding
        style.append(("LEFTPADDING", (0,0), (-1,-1), 6))
        style.append(("LEFTPADDING", (0,0), (0,-1), 0))
        style.append(("RIGHTPADDING", (0,0), (-1,-1), 6))
        style.append(("BOTTOMPADDING", (0,0), (-1,-1), 0))
        style.append(("TOPPADDING", (0,0), (-1,-1), 0.6*FONTSIZE))

        # alignment
        style.append(("VALIGN", (0,0), (-1,-1), "MIDDLE"))
        style.append(("ALIGN", (0,0), (-1,-1), "LEFT"))

        # apply style
        t.setStyle(TableStyle(style))
        self.append(t)

        
    def appendData(self, dict):
        heads = dict['head']
        values = dict['value']
        rows = len(heads)
        
        # prepare data
        data = []
        for i in range(len(heads)):
            data.append([heads[i], values[i]])
        rows = len(data)

        # row heights
        rh = rows*[1.6*FONTSIZE]
        
        # prepare table
        data = specialTab(data)
        t = FullTable(data, None, rh)
        t.setTabWidth(self.tabwidth)
        style = []

        # fonts
        style.append(("FONT", (0,0), (-1,-1), FONT))
        style.append(("FONTSIZE", (0,0), (-1,-1), FONTSIZE))

        # cell padding
        style.append(("LEFTPADDING", (0,0), (-1,-1), 6))
        style.append(("RIGHTPADDING", (0,0), (-1,-1), 6))
        style.append(("BOTTOMPADDING", (0,0), (-1,-1), 0))
        style.append(("TOPPADDING", (0,0), (-1,-1), 0.6*FONTSIZE))

        # line grid
        style.append(("GRID", (0,0), (-1,-1), LINE, colors.black))

        # alignment
        style.append(("VALIGN", (0,0), (-1,-1), "MIDDLE"))
        style.append(("ALIGN", (0,0), (-1,-1), "LEFT"))

        # apply style
        t.setStyle(TableStyle(style))
        self.append(t)
        

    def appendSmalltable(self, dict):
        list = dict['list']
        align = dict['align']
        width = dict['width']
        
        # prepare data
        data = []
        for key, item in list:
            data.append([key, item])
        rows = len(data)

        # row heights
        rh = rows*[1.6*FONTSIZE]
        #rh[0] = 0
        
        # prepare table
        data = specialTab(data)
        t = Table(data, None, rh)
        t.hAlign = align.upper()
        style = []

        # fonts
        style.append(("FONT", (0,0), (-1,-1), FONT))
        style.append(("FONTSIZE", (0,0), (-1,-1), FONTSIZE))

        # cell padding
        style.append(("LEFTPADDING", (0,0), (-1,-1), 6))
        style.append(("RIGHTPADDING", (0,0), (-1,-1), 6))
        style.append(("BOTTOMPADDING", (0,0), (-1,-1), 0))
        style.append(("TOPPADDING", (0,0), (-1,-1), 0.6*FONTSIZE))

        # line grid
        style.append(("GRID", (0,0), (-1,-1), LINE, colors.black))

        # alignment
        style.append(("VALIGN", (0,0), (-1,-1), "MIDDLE"))
        style.append(("ALIGN", (0,0), (-1,-1), "LEFT"))

        # apply style
        t.setStyle(TableStyle(style))
        self.append(t)
        

    def appendTable(self, dict):
        cols = len(dict['cols'])
        rows = len(dict['rows'])
        head = dict['shead']
        data = dict['data']
        width = dict['width']
        align = dict['align']
        foot = dict['foot']
        falign = dict['falign']

        skip = []
        for i in range(len(head)):
            if not head[i]:
                skip.append(i)
        if skip:
            for pos in range(len(skip)):
                i = skip[pos] - pos
                cols = cols - 1
                del head[i]
                if width:
                    del width[i]
                if align:
                    del align[i]
                if foot:
                    del foot[i]
                if falign:
                    del falign[i]
                for j in range(len(data)):
                    del data[j][i]

        # apply head and foot
        data = [head] + data
        rows = rows + 1
        if foot:
            data = data + [foot]
            rows = rows + 1
        
        # row heights
        rh = rows*[1.6*FONTSIZE]
        
        # prepare table
        data = specialTab(data)
        #t = Table(data, cw, rh)
        t = FullTable(data, None, rh)
        t.setTabWidth(self.tabwidth)
        style = []

        # fonts
        style.append(("FONT", (0,0), (-1,0), BOLD))
        style.append(("FONT", (0,1), (-1,-1), FONT))
        if foot:
            style.append(("FONT", (0,-1), (-1,-1), BOLD))
        style.append(("FONTSIZE", (0,0), (-1,-1), FONTSIZE))

        # cell padding
        style.append(("LEFTPADDING", (0,0), (-1,-1), 6))
        style.append(("RIGHTPADDING", (0,0), (-1,-1), 6))
        style.append(("BOTTOMPADDING", (0,0), (-1,-1), 0))
        style.append(("TOPPADDING", (0,0), (-1,-1), 0.6*FONTSIZE))

        # line grid
        style.append(("GRID", (0,0), (-1,-1), LINE, colors.black))

        # background colors
        for i in range(rows):
            if i % 2:
                style.append(("BACKGROUND", (0,i), (-1,i),
                              colors.Color(0.8,0.8,0.8)))
        style.append(("BACKGROUND", (0,0), (-1,0),
                      colors.Color(1.0,1.0,0.5)))
        if foot:
            style.append(("BACKGROUND", (0,-1), (-1,-1),
                          colors.Color(1.0,1.0,0.5)))
        
        # alignment
        style.append(("VALIGN", (0,0), (-1,-1), "MIDDLE"))
        for i in range(cols):
            a = align[i].upper()
            style.append(("ALIGN", (i,0), (i,-1), a))
            style.append(("ALIGN", (i,0), (i,0), "CENTER"))
            if foot:
                f = falign[i].upper()
                style.append(("ALIGN", (i,-1), (i,-1), f))

        # apply style
        t.setStyle(TableStyle(style))
        self.append(t)
        

######################################################################
def pdfout(list, version, name, date, time, user):
    d = IHSDocument(version, name, date, time, user)
    
    for key, value in list:
        if key == "Headtable":
            d.appendHeadtable(value, "LEFT")
        elif key == "Foottable":
            d.appendHeadtable(value, "RIGHT")
        elif key == "Headline":
            d.appendHeadline(value)
        elif key == "Spacer":
            d.appendSpacer(value)
        elif key == "Table":
            d.appendTable(value)
        elif key == "Smalltable":
            d.appendSmalltable(value)
        elif key == "Data":
            d.appendData(value)
        elif key == "Pagebreak":
            d.pageBreak()
        elif key == "Formhead":
            continue
        elif key == "Formfoor":
            continue
        else:
            raise RuntimeError(key)  
    d.build()
    return str(d)
    

######################################################################
if __name__ == "__main__":
    import sys

    head = [
        ("Fonds:", "", "612 936 00"),
        ("Fonds:", "", "612 936 00"),
        ("Fonds:", "", "612 936 00"),
        ]

    dict = {}
    dict['data'] = [[1, 2, 3, 4, 5],
                    [1, 2, 3, 4, 5],
                    [1, 2, 3, 4, 5],
                    [1, 2, 3, 4, 5],
                    [1, 2, 3, 4, 5],
                    [1, 2, 3, 4, 5],
                    [1, 2, 3, 4, 5]]
    dict['cols'] = range(len(dict["data"][0]))
    dict['rows'] = range(len(dict["data"]))
    dict['shead'] = ["Anzahl", "Text", "Werttyp", "Datum", "Betrag"]
    dict['width'] = ["100%", "100%", "100%", "100%", "100%"]
    dict['align'] = ["left", "center", "center", "center", "right"]
    dict['foot'] = ["Gesamt", "", "", "", "100"]
    dict['falign'] = ["left", "center", "center", "center", "right"]

    list = [
        ("HeadTab", head),
        ("Spacer", 1.5*FONTSIZE),
        ("Table", dict),
        ]

    version = "<version>"
    name = "<name>"
    date = "<date>"
    time = "<time>"
    user = "<user>"
    
    s = pdfout(list, version, name, date, time, user)
        
    fp = open("a.pdf", "w")
    fp.write(s)
    fp.close()
