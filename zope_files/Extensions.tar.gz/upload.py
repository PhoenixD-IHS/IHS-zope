import os.path

# Fixed storage folder:
PATH = "/usr/local/share/ihs/var/zopeinstance/import/"

def upload(zopefile):
    fn = zopefile.filename
    fn = os.path.split(fn)[1]
    if not fn:
        return None
    
    path = os.path.join(PATH, fn) 
    fp = open(path, "wb")
    fp.write(zopefile.read())
    fp.close()

    return fn
